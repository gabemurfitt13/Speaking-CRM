# Gabe Murfitt Speaker CRM

A simple browser-based CRM for tracking school outreach, speaking leads, follow-ups, notes, and booked presentations.

## How to use

Open `index.html` in a browser or publish it with GitHub Pages.

Your updates are saved in your browser using localStorage. That means the data stays on the device/browser you use. It is not a shared cloud database.

## GitHub Pages setup

1. Create a new GitHub repository named `speaker-crm`.
2. Upload `index.html` to the repository root.
3. Go to Settings > Pages.
4. Under "Build and deployment," choose "Deploy from a branch."
5. Select the `main` branch and `/root`, then save.
6. GitHub will provide a live URL after it deploys.
